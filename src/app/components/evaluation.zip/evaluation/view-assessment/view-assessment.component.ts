import { Component } from '@angular/core';

@Component({
  selector: 'app-view-assessment',
  standalone: true,
  imports: [],
  templateUrl: './view-assessment.component.html',
  styleUrl: './view-assessment.component.css'
})
export class ViewAssessmentComponent {

}
